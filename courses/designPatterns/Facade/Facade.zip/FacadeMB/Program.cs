﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FacadeMB
{
    class Program
    {
        /// <summary>
        /// https://referencesource.microsoft.com/#System.Windows.Forms/winforms/Managed/System/WinForms/MessageBox.cs,e426fc24b95c791e
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            MessageBox.Show("this is a simple message");
            int i = 0;
            while(MessageBox.Show("Do you want to continue ?","Question "+i,MessageBoxButtons.YesNo) != DialogResult.No)
            {
                i++;
            }
        }
    }
}
//   private static DialogResult ShowCore(IWin32Window owner, string text, string caption,   
//                                             MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton,
//                                             MessageBoxOptions options, bool showHelp) {
       
//            if (!ClientUtils.IsEnumValid(buttons, (int)buttons, (int)MessageBoxButtons.OK, (int)MessageBoxButtons.RetryCancel)){
//               throw new InvalidEnumArgumentException("buttons", (int)buttons, typeof(MessageBoxButtons));
//            }
 
//            // valid values are 0x0 0x10 0x20 0x30 0x40, chop off the last 4 bits and check that it's between 0 and 4.
//            if (!WindowsFormsUtils.EnumValidator.IsEnumWithinShiftedRange(icon, /*numBitsToShift*/4, /*min*/0x0,/*max*/0x4)) {
//                throw new InvalidEnumArgumentException("icon", (int)icon, typeof(MessageBoxIcon));
//            }
//            // valid values are 0x0 0x100, 0x200, chop off the last 8 bits and check that it's between 0 and 2.
//            if (!WindowsFormsUtils.EnumValidator.IsEnumWithinShiftedRange(defaultButton, /*numBitsToShift*/8, /*min*/0x0,/*max*/0x2)) {
//                throw new InvalidEnumArgumentException("defaultButton", (int)defaultButton, typeof(DialogResult));
//            }
            
//            // options intentionally not verified because we don't expose all the options Win32 supports.
 
//            if (!SystemInformation.UserInteractive && (options & (MessageBoxOptions.ServiceNotification | MessageBoxOptions.DefaultDesktopOnly)) == 0) {
//                throw new InvalidOperationException(SR.GetString(SR.CantShowModalOnNonInteractive));
//            }
//            if (owner != null && (options & (MessageBoxOptions.ServiceNotification | MessageBoxOptions.DefaultDesktopOnly)) != 0) {
//                throw new ArgumentException(SR.GetString(SR.CantShowMBServiceWithOwner), "options");
//            }
//            if (showHelp && (options & (MessageBoxOptions.ServiceNotification | MessageBoxOptions.DefaultDesktopOnly)) != 0) {
//                throw new ArgumentException(SR.GetString(SR.CantShowMBServiceWithHelp), "options");
//            }
 
//            // demand if not safe known options.
//            if ((options & ~(MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading)) != 0) {
//                // See DDB#163043.
//                IntSecurity.UnmanagedCode.Demand();
//            }
 
//            IntSecurity.SafeSubWindows.Demand();
 
//            int style = (showHelp) ? HELP_BUTTON : 0;
//style |= (int) buttons | (int) icon | (int) defaultButton | (int) options;
 
//            IntPtr handle = IntPtr.Zero;
//            if (showHelp || ((options & (MessageBoxOptions.ServiceNotification | MessageBoxOptions.DefaultDesktopOnly)) == 0)) {
//                if (owner == null) {
//                    handle = UnsafeNativeMethods.GetActiveWindow();
//                }
//                else {
//                    handle = Control.GetSafeHandle(owner);
//                }
//            }
 
//            IntPtr userCookie = IntPtr.Zero;
 
//            if (Application.UseVisualStyles) {
//                // CLR4.0 or later, shell32.dll needs to be loaded explicitly.
//                if (UnsafeNativeMethods.GetModuleHandle(ExternDll.Shell32) == IntPtr.Zero) {
//                    if (UnsafeNativeMethods.LoadLibrary(ExternDll.Shell32) == IntPtr.Zero) {
//                        int lastWin32Error = Marshal.GetLastWin32Error();
//                        throw new Win32Exception(lastWin32Error, SR.GetString(SR.LoadDLLError, ExternDll.Shell32));
//                    }
//                }
 
//                // Activate theming scope to get theming for controls at design time and when hosted in browser.
//                // NOTE: If a theming context is already active, this call is very fast, so shouldn't be a perf issue.
//                userCookie = UnsafeNativeMethods.ThemingScope.Activate();
//            }
 
//            Application.BeginModalMessageLoop();
//            DialogResult result;
//            try {
//                result = Win32ToDialogResult(SafeNativeMethods.MessageBox(new HandleRef(owner, handle), text, caption, style));
//            }
//            finally {
//                Application.EndModalMessageLoop();
//                UnsafeNativeMethods.ThemingScope.Deactivate(userCookie);
//            }
 
//            // Right after the dialog box is closed, Windows sends WM_SETFOCUS back to the previously active control 
//            // but since we have disabled this thread main window the message is lost. So we have to send it again after
//            // we enable the main window.
//            //
//            UnsafeNativeMethods.SendMessage(new HandleRef(owner, handle), NativeMethods.WM_SETFOCUS, 0, 0);
//            return result;
//        }

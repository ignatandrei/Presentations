﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FacadeWebClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var wc = new WebClient();
            var s = wc.DownloadString("http://www.yahoo.com");
            Console.WriteLine(s);

        }
    }
}

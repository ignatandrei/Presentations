﻿Imports System.Threading

Module Module1

    Sub Main()
        My.Application.ChangeCulture("en-US")
        WriteCurrentCulture()
        My.Application.ChangeCulture("fr-FR")
        WriteCurrentCulture()


        My.Computer.Audio.PlaySystemSound(Media.SystemSounds.Beep)
        My.Computer.Clipboard.SetText("asdasd")

    End Sub
    Sub WriteCurrentCulture()
        Console.WriteLine(My.Application.Culture)
        Console.WriteLine(Thread.CurrentThread.CurrentCulture)

    End Sub


End Module

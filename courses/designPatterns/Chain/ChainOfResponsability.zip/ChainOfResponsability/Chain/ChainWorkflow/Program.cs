﻿using System;

namespace ChainWorkflow
{
    class Program
    {
        static void Main(string[] args)
        {
            ApproverForExpense CEO = new Director();
            ApproverForExpense manager = new Manager(CEO);
            manager.Approve(new Expense() { amount = 10 });
            manager.Approve(new Expense() { amount = 500 });

        }

        class Expense
        {
            public int amount;
        }
        abstract class ApproverForExpense
        {
            public ApproverForExpense(ApproverForExpense next)
            {
                Next = next;
            }

            internal ApproverForExpense Next { get; }

            public abstract bool Approve(Expense e);

        }

        class Manager : ApproverForExpense
        {
            public Manager(ApproverForExpense next) :base(next)
            {
                
            }
            public override bool Approve(Expense e)
            {
                if (e.amount < 100)
                    return true;

                return base.Next.Approve(e);
            }
        }
        class Director : ApproverForExpense
        {
            public Director():base(null)
            {

            }
            public override bool Approve(Expense e)
            {
                if (e.amount < 1000)
                    return true;

                return false;
            }
        }
    }
}

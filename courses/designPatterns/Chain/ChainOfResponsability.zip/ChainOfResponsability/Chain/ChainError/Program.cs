﻿using System;

namespace ChainError
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            y();
        }
        static int y()
        {
            try
            {
                x();
                return 5;
            }
            catch (Exception ex)
            {
                throw new Exception("from y", ex);
            }
        }
        static int x()
        {
            throw new ArgumentException("argument");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;

namespace Chain
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            //Middleware in line
            app.Use(async (context, next) =>
            {
                await next();
                await context.Response.WriteAsync("<div>https://www.jeffogata.com/asp-net-core-middleware/, after await, https://docs.microsoft.com/en-us/aspnet/core/fundamentals/middleware?tabs=aspnetcore2x</div>");
                await context.Response.WriteAsync("</body></html>");
            });

            app.UseMiddleware<MyMiddleware>();
            //Middleware class
            app.UseStaticFiles();
            
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
            
        }
        public class MyMiddleware
        {
            private readonly RequestDelegate _next;

            public MyMiddleware(RequestDelegate next)
            {
                _next = next;
            }

            public async Task Invoke(HttpContext context)
            {

                var id = context.Request.Query["id"];
                if (!string.IsNullOrWhiteSpace(id))
                {
                    if (id == "Andrei")
                        context.Request.QueryString =new QueryString(context.Request.QueryString.Value.Replace("id=Andrei", "id=5"));

                }
                // Call the next delegate/middleware in the pipeline
                await _next(context);

            }
        }
    }
}

﻿namespace VisitorDoubleDispatch
{
    /// <summary>
    /// https://blogs.msdn.microsoft.com/shawnhar/2011/04/05/visitor-and-multiple-dispatch-via-c-dynamic/
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Animal a = new Dog();
            Exporter e = new Exporter();
            e.Export(a);

            //visitor to have the real type
            Visitor v = new Visitor();
            a.Visit(v);

            //double dispatch dynamic
            e.Export(a as dynamic);
        }
    }
}

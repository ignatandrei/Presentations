﻿using System;

namespace VisitorDoubleDispatch
{
    class Exporter
    {
        public void Export(Animal a)
        {
            Console.WriteLine("visit animal that is real "+a.Say());
        }
        public void Export(Dog d)
        {
            Console.WriteLine("visit real dog");
        }
        public void Export(Cat c)
        {
            Console.WriteLine("visit real cat");
        }

    }
}

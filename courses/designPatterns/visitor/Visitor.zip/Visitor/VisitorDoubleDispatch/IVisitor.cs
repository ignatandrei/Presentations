﻿using System;

namespace VisitorDoubleDispatch
{
    public interface IVisitor
    {
        void Visit(Animal a);
        void Visit(Dog d);
        void Visit(Cat c);
        
    }
    class Visitor : IVisitor
    {
        public void Visit(Animal a)
        {
            Console.WriteLine("animal");
        }

        public void Visit(Dog d)
        {
            Console.WriteLine("dog");
        }

        public void Visit(Cat c)
        {
            Console.WriteLine("cat");
        }
    }
}

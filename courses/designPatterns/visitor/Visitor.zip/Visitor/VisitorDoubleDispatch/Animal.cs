﻿using System;

namespace VisitorDoubleDispatch
{
    public abstract class Animal
    {
        public string Say()
        {
            return("My type :" + this.GetType().Name);
        }

        #region visitor
        public abstract void Visit(IVisitor visitor);
        //cannot be implemented here!!
        #endregion

    }
    public class Dog :Animal
    {
        public override void Visit(IVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
    public class Cat : Animal
    {
        public override void Visit(IVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}

﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System;
using System.Diagnostics;
using System.IO;

namespace RoslynVisitor
{
    class Program
    {
        /// <summary>
        /// for more details 
        /// https://github.com/ignatandrei/AOP_With_Roslyn
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            var Code = File.ReadAllText("Code.txt");
            var tree = CSharpSyntaxTree.ParseText(Code);

            var node = tree.GetRoot();

            var LG = new MethodRewriter("string s=\"this is method {nameMethod} from class {nameClass} at line {lineStartNumber}\";", "s=\"\";");
            var sn = LG.Visit(node);
            var newFile = "new.txt";
            if (File.Exists(newFile))
                File.Delete(newFile);
            File.WriteAllText(newFile, sn.NormalizeWhitespace().ToFullString());
            Process.Start("notepad.exe",newFile);
        }
    }
}

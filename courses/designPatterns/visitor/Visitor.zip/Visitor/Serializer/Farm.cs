﻿using System;
using System.Collections.Generic;
using System.Text;
using VisitorDoubleDispatch;

namespace Serializer
{
    public interface IAcceptVisitorAnimals
    {
        void Accept(IVisitor v);
    }
    public class Farm: IAcceptVisitorAnimals
    {
        public Farm()
        {
            animals = new List<Animal>();
        }
        public List<Animal> animals;
        public string ExportToXML()
        {
            foreach(var item in animals)
            {
                //todo:
                //animal.ExportToXML();
            }
            return "export XML";
        }
        public string ExportToCSV()
        {
            foreach (var item in animals)
            {
                //todo:
                //animal.ExportToXML();
            }
            return "export CSV";
        }

        public void Accept(IVisitor v)
        {

            foreach (var item in animals)
            {
                //todo:
                item.Visit(v);
            }
            
        }
    }
}

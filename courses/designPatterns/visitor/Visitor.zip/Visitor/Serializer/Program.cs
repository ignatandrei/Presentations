﻿using System;
using VisitorDoubleDispatch;

namespace Serializer
{
    class VisitorCSV : IVisitor
    {
        public string Csv { get; private set; }
        public void Visit(Animal a)
        {
            Csv += ",visit animal";
        }

        public void Visit(Dog d)
        {
            Csv += ",visit dog";
        }

        public void Visit(Cat c)
        {
            Csv += ",visit cat";
        }
    }
    class Program
    {
        /// <summary>
        /// difference between decorator and visitor?
        /// 1. hierarchies visiting
        /// 2. decorator is deriving from the same class( chocolate with topping)
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            // Export to XML
            Farm f = new Farm();
            f.animals.Add(new Dog());
            f.animals.Add(new Cat());
            //f.ExportToCSV();
            //f.ExportToXML();

            VisitorCSV v = new VisitorCSV();
            f.Accept(v);
            Console.WriteLine(v.Csv);

            //Export to csv
        }
    }
}

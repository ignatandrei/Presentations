﻿using QueryInterceptor.Core;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace ExpressionVisitor1
{
    public class EqualsToNotEqualsVisitor : ExpressionVisitor
    {
        protected override Expression VisitBinary(BinaryExpression node)
        {
            if (node.NodeType == ExpressionType.Equal)
            {
                // Change == to !=
                return Expression.NotEqual(node.Left, node.Right);
            }
            return base.VisitBinary(node);
        }
        
    }

    class Program
    {
        //	https://github.com/StefH/QueryInterceptor.Core
        static void Main(string[] args)
        {
            var query = from n in Enumerable.Range(0, 10).AsQueryable()
                        where n % 2 == 0
                        select n;

            // Print even numbers
            foreach (var item in query)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();

            // Print odd numbers
            var visitor = new EqualsToNotEqualsVisitor();
            foreach (var item in query.InterceptWith(visitor))
            {
                Console.WriteLine(item);
            }
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
namespace EFCoreGlobalQueryFilter
{
    class Program
    {
        /// <summary>
        /// https://github.com/aspnet/EntityFrameworkCore/blob/1325b6ec1816c4372b92de16bae4b5e811223a18/src/EFCore/Query/ExpressionVisitors/Internal/ModelExpressionApplyingExpressionVisitor.cs
        /// if (!_queryCompilationContext.IgnoreQueryFilters
        ///                && entityType.QueryFilter != null)
        /// public class ModelExpressionApplyingExpressionVisitor : RelinqExpressionVisitor               
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            var options = new DbContextOptionsBuilder<BloggingContext>()
                .UseInMemoryDatabase(databaseName: "Add_writes_to_database")
                .Options;

            // Run the test against one instance of the context
            using (var context = new BloggingContext(options))
            {
                context.Blogs.Add(new Blog()
                {
                    Url = "http://msprogrammer.serviciipeweb.ro"
                });
                context.SaveChanges();

            }
            using (var context = new BloggingContext(options))
            {
                var b = context.Blogs
                    .FirstOrDefault(it => it.Url.Contains("mspr"));
                Console.WriteLine(b == null);

            }

            using (var context = new BloggingContext(options))
            {
                
                var b = context.Blogs
                    .IgnoreQueryFilters()
                    .FirstOrDefault(it => it.Url.Contains("mspr"));
                Console.WriteLine(b.Id);

            }
        }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace EFCoreGlobalQueryFilter
{
    public class Blog
    {
       
        public int Id { get; set; }
        public string Url { get; set; }
    }
}
﻿global using System;
global using System.IO;

global using static System.Console;
global using static System.IO.Directory;
global using System.Formats.Tar;
global using System.IO.Compression;
global using System.Runtime.InteropServices;
global using static Net7Demo.demoImport;

﻿namespace AT_DAL
{
    public class Person
    {
        public int ID { get; set; }
        public string Name { get; set; }

    }
}

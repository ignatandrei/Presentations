﻿using System;

namespace GeneratedDemo
{
    class Program
    {
        static void Main(string[] args)
        {
      

            Console.WriteLine("\n\nRunning CsvGenerator:\n");
            UseCsvGenerator.Run();

            Console.WriteLine("\n\nRunning XmlSettings:\n");
            UseXmlSettingsGenerator.Run();

        }
    }
}

﻿using System;

namespace RSCG_VerySimple
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            MyTest.WriteDate(); 
        }
    }
}

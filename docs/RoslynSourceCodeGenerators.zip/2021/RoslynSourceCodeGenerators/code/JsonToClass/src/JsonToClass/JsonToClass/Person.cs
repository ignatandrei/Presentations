﻿namespace JsonToClass
{
    partial class Person
    {
        public string FullName() => FirstName + LastName;
    }
}

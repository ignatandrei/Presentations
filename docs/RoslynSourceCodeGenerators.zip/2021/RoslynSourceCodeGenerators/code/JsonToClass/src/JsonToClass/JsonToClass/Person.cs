﻿namespace JsonToClass.Json.Persons
{
    partial class Person
    {
        public string FullName() => FirstName + LastName;
    }
}

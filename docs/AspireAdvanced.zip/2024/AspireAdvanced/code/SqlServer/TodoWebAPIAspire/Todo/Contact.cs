﻿public record Contact(int Id, string FirstName, string LastName, string Email, string? Phone);

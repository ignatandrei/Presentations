﻿using Aspire.Hosting.ApplicationModel;
//shameless copy from https://github.com/davidfowl/AspireSwaggerUI
namespace AddAutomation;

public class SwaggerUIResource(string name) : Resource(name)
{

}

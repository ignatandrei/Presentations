﻿global using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
global using Microsoft.AspNetCore.Components.Web;
global using ZipAsAService.WebAssembly;
global using Blazor.DownloadFileFast.Interfaces;
global using ZipAsAService.Web;
//global using ZipAsAService.Web.Components;
global using System.Net.Http.Json;



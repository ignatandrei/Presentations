﻿namespace CSharp8WhatsNew
{
    interface IAnimal
    {
        string baseType() => "animal";
    }
}

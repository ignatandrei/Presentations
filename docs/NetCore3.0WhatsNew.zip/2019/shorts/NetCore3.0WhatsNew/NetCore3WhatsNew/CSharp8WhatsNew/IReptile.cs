﻿namespace CSharp8WhatsNew
{
    interface IReptile
    {
        string baseType() => "Reptile";
        int  NumberEggs();

    }
}

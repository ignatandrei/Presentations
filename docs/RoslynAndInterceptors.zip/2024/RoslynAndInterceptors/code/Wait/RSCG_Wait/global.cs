﻿global using Microsoft.CodeAnalysis;

﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine(RSCG_Wait.MyGeneratedCode.DateStart);
Console.WriteLine(RSCG_Wait.MyGeneratedCode.SecondsToWait);
Console.WriteLine(RSCG_Wait.MyGeneratedCode.DateEnd);
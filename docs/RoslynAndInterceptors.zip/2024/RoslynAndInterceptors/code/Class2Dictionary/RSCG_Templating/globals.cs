﻿global using Microsoft.CodeAnalysis;
global using Microsoft.CodeAnalysis.CSharp;
global using Microsoft.CodeAnalysis.CSharp.Syntax;
global using System.Collections.Immutable;
global using Scriban;
global using RSCG_TemplatingCommon.InterfacesV1; 
global using RSCG_Templating.ImplementV1;
import React from 'react';
function Sister(){
    return (
        <div>I am sister</div>
    )

}


export default Sister;
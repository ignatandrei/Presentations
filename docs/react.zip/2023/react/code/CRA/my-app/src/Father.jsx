import React from 'react';
import Brother from './Brother';
import Sister from './Sister';
function Father() {
    return (
        <>
            <div>I am father</div>
            <Brother></Brother>
            <Sister></Sister>
        </>
    )

}


export default Father;
import React from 'react';
import Father from './Father';
function GrandFather(props) {
    return (
        <>
            <div>I am grandfather</div>
            <Father></Father>
            
        </>
    )

}


export default GrandFather;
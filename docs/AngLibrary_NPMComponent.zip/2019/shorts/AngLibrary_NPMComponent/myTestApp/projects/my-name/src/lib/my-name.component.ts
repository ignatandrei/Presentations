import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ignatandrei-my-name',
  template: `
    <p>
      andrei asdasdignat works!
    </p>
  `,
  styles: []
})
export class MyNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

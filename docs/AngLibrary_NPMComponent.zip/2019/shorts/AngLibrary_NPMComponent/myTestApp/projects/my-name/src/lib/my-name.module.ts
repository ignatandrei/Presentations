import { NgModule } from '@angular/core';
import { MyNameComponent } from './my-name.component';

@NgModule({
  declarations: [MyNameComponent],
  imports: [
  ],
  exports: [MyNameComponent]
})
export class MyNameModule { }

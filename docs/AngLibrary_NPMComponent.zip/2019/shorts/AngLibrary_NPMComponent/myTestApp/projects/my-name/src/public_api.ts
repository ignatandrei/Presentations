/*
 * Public API Surface of my-name
 */

export * from './lib/my-name.service';
export * from './lib/my-name.component';
export * from './lib/my-name.module';

﻿global using System.IO.Compression;
global using Microsoft.Extensions.Time.Testing;
global using System;
global using static System.Console;
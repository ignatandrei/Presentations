﻿global using static System.Console;
global using WhatsNewEFCore8;

﻿global using static System.Console;
global using WhatsNewEFCore8;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Options;
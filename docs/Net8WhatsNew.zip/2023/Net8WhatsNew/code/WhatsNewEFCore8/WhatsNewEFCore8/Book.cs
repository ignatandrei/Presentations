﻿namespace WhatsNewEFCore8;
public record Book(long ID ,string Name)
{
}

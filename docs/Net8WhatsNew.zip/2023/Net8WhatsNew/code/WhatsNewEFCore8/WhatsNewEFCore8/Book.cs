﻿namespace WhatsNewEFCore8;
public record Book(int ID ,string Name)
{
}

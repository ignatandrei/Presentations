﻿using RSCG_TemplatingDemo;

var x = new Person();
Console.WriteLine("The generated string type is " + x.MyTypeName);
x.FirstName = "Andrei";
//set last name via prop
x.SetPropValue(ePerson_Properties.LastName, "Ignat");
Console.WriteLine("called directly first name : " + x.FirstName);
Console.WriteLine("called via enum of prop first name : " + x.GetPropValue(ePerson_Properties.FirstName));
Console.WriteLine("called get property :" + x.GetPropValue(ePerson_Properties.Name));

Console.WriteLine("this will throw error because Name has not set ");
try
{
    x.SetPropValue(ePerson_Properties.Name, "asd");
}
catch (Exception)
{
    Console.WriteLine("this is good!");
}
Console.ReadLine();
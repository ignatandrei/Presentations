﻿global using System.ComponentModel.DataAnnotations;
global using System.Diagnostics;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.Options;
global using WhatsNewASPNetCore8;
global using WhatsNewASPNetCore8.HS;
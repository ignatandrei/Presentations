﻿#nullable disable
namespace EFCore6WebAPI;

class TenantProp
{
    public int MyId { get; set; }
}


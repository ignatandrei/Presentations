﻿global using Microsoft.EntityFrameworkCore;
global using System;
global using System.Collections.Generic;
global using EFCore6WebAPI;
global using Microsoft.EntityFrameworkCore.Storage.ValueConversion;


﻿global using static System.Console;
global using static System.Linq.Enumerable;
global using static System.IO.Directory;
global using static System.String;
global using static System.Math;
global using System.Collections.Generic;
global using GlobalUsings;
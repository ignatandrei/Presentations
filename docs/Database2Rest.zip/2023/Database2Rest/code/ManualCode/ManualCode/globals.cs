﻿global using Microsoft.AspNetCore.Mvc;
global using DalManual;
global using Microsoft.EntityFrameworkCore;
global using System.Configuration;

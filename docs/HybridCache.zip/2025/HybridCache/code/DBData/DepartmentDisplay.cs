﻿namespace DBData;
[RSCG_IFormattableCommon.AddIFormattable]
public partial class DepartmentDisplay
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public int Employees { get; set; } 
}

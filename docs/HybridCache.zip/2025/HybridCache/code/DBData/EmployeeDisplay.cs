﻿namespace DBData;
[RSCG_IFormattableCommon.AddIFormattable]
public partial class EmployeeDisplay
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string DepartmentName { get; set; } = null!; 
}

﻿using System;

namespace DiamondD1_2
{
    /// <summary>
    /// <CopyLocalLockFileAssemblies>true</CopyLocalLockFileAssemblies>
    /// </summary>
    public class clsTest
    {
        public string GetMyBlog(string blog)
        {

            return blog;
        }
        //public string GetMyBlog()
        //{
        //    return "http://msprogrammer.serviciipeweb.ro/";
        //}
    }
}

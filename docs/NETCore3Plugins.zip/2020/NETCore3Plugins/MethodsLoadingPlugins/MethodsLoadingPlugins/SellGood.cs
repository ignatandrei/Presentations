﻿namespace MethodsLoadingPlugins
{
    public class SellGood
    {
        public string Name { get; set; }
        public double Price { get; set; }
    }


}

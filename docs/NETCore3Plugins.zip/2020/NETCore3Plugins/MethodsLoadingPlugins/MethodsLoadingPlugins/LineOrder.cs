﻿namespace MethodsLoadingPlugins
{
    public class LineOrder
    {
        public SellGood sellGood {get;set;}
        public int Number { get; set; }
    }


}

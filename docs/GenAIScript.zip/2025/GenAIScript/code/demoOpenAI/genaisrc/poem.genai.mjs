script({
    model: "azure:gpt-4o-mini",
})
$`Write a short poem in code.`

script({
    model: "ollama:llama3.2",
})
$`Write a short poem in code.`

cls
#nu a mersL: npx genaiscript run befCommit --model "azure_serverless:Llama-3-3-70B-Instruct-oapyq"
#   TODO: OPENAI_API_TYPE=localai in .env
# npx genaiscript run befCommit --model "gpt-4" 
#npx genaiscript run befCommit --model "ollama:llama3.2"
#npx genaiscript run befCommit     --model "transformers:onnx-community/Qwen2.5-Coder-0.5B-Instruct:q4"
npx genaiscript run befCommit     --model "ollama:phi3.5" 
#npx genaiscript run befCommit     --model "ollama:phi4" 
#npx genaiscript run befCommit     --model "ollama:gemma2:27b"
#npx genaiscript run befCommit     --model "deepseek-r1"


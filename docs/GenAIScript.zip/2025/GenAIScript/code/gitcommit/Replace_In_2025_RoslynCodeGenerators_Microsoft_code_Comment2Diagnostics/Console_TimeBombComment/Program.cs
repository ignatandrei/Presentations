﻿using Console_TimeBombComment;

Console.WriteLine("See TestClass with comments");
Console.WriteLine(TestClass.FoundTimeBombComment_0());

//Added for testing
//TODO 2025-09-13 we should change fix
﻿global using Polly;
global using System;
global using System.Net;
global using static System.Console;
﻿using Console_TimeBombComment;

Console.WriteLine("See TestClass with comments");
Console.WriteLine(TestClass.FoundTimeBombComment_0());
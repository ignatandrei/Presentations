﻿namespace Console_TimeBombComment;

internal partial class TestClass
{
    public static int CommentsWithErrors()
    {
        //TODO 2025-09-13 we should change fix
        return 5;
    }
}

﻿
WriteLine("Hello RSCG!");
MyTest.WriteDate();

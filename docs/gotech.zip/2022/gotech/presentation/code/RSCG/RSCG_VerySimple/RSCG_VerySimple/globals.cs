﻿global using System;
global using static System.Console;
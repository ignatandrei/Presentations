﻿global using OpenTelemetry.Trace; 
global using OpenTelemetry.Resources;
global using System.Runtime.CompilerServices;
global using System.Diagnostics;


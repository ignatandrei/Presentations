﻿global using Microsoft.Extensions.Configuration;
global  using static System.Console;
global using Microsoft.Extensions.DependencyInjection;
global using OpenTelemetry.Resources;
global using OpenTelemetry;
global using System.Diagnostics;
global using OpenTelemetry.Trace;
global using DemoConsoleOpenTelemetry;
global using System.Runtime.CompilerServices;


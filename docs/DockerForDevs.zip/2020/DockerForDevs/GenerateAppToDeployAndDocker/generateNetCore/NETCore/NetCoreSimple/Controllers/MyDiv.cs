﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreSimple.Controllers
{
    public class MyDiv
    {
        public int x { get; set; }
        public int y { get; set; }
    }
}

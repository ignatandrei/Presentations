﻿namespace whatsNewNet10.Web;

public class PhoneNumber
{
}
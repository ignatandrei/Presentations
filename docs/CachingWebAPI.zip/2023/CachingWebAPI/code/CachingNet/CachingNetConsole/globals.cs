﻿global using CachingNetObj;
global using Microsoft.Extensions.Caching.Memory;
global using static System.Console;
global using static System.Threading.Tasks.Task;
global using CachingNetConsole;
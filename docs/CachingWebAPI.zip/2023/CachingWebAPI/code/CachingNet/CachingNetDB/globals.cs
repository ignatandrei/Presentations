﻿global using Microsoft.EntityFrameworkCore;

global using Microsoft.Data.SqlClient;

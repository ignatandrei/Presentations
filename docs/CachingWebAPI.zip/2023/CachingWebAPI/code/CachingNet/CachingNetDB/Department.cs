﻿using System;
using System.Collections.Generic;

namespace CachingNetDB;

public partial class Department
{
    public long IdDept { get; set; }

    public string Name { get; set; } = null!;
}

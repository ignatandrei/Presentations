﻿using System;
using System.Collections.Generic;

namespace EFCoreDemos;

//andrei - here is entity name
public partial class Test
{
    public int? Id { get; set; }

    public string? Name { get; set; }
}

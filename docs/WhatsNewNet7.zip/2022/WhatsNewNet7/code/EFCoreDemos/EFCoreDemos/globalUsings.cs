﻿global using EFCoreDemos;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.AspNetCore.Http;
global using Microsoft.AspNetCore.Mvc;
global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Threading.Tasks;
global using NetCore2BlocklyNew;
global using Microsoft.EntityFrameworkCore.Diagnostics;


